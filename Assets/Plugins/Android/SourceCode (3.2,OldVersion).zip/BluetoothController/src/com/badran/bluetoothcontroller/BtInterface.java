package com.badran.bluetoothcontroller;
/* Android PlugIn for Unity Game Engine
 * By Tech Tweaking
 * 
 */

import android.bluetooth.BluetoothAdapter;


import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Set;
import java.util.UUID;



import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import com.unity3d.player.UnityPlayer;


public class BtInterface extends Thread {
	
 
	
	class MessagesThread {
		public volatile ArrayList<Object []> outMessages = new ArrayList<Object []>();
		
		public volatile char charMessage = (char)0;
		public volatile String stringMessage = "";
		public volatile byte[] bytesMessage  = new byte []{};
	  }
	private final  MessagesThread messagesThread = new MessagesThread();
	
	private BluetoothDevice device = null;
	private BluetoothSocket socket = null;
	private BluetoothAdapter mBluetoothAdapter = null;
	private InputStream receiveStream = null;
	private BufferedReader receiveReader = null;
	private OutputStream sendStream = null;	
	
	private PrintWriter writer = null;
	private BufferedOutputStream outBufferStream = null;
	private BtReceiver RECEIVER;
	private BtSender SENDER;
		
	private boolean sending = true;
	
	private boolean isConnected = false;
	
	private boolean bufferDataAvailable = false;
	private boolean dataAvailable = false;
	private boolean lineAvailable = false;
	
	private byte [] buffer = {};
	private byte [] tempBuffer = {};
	private String stringData = "";
	
	volatile int modeIndex2 = 0;
	
	class ControlThread {
	    public volatile boolean MODE = true;
	    public volatile boolean MODE2 = false;
	    public volatile boolean MODE3 = false;
	    public volatile boolean startListen = true;
	    public volatile boolean listening = false;
	    public volatile byte stopByte ;
	    public volatile int length = 0;
	    public volatile boolean isSending = false;
	  }
	
	private final ControlThread control = new ControlThread();
	public BtInterface(BluetoothAdapter tempBluetoothAdapter) {
		this.mBluetoothAdapter =tempBluetoothAdapter;
	}
	
	public void run() {
		
		Set<BluetoothDevice> setpairedDevices = mBluetoothAdapter.getBondedDevices();
    	BluetoothDevice[] pairedDevices = (BluetoothDevice[]) setpairedDevices.toArray(new BluetoothDevice[setpairedDevices.size()]);
		boolean foundModule = false;
		
		for(int i=0;i<pairedDevices.length;i++) {
			if(this.isInterrupted()) return;
			boolean temp ;
			if(Bridge.mac)
				temp = pairedDevices[i].getAddress().equals(Bridge.ModuleMac);
			else 
				temp = pairedDevices[i].getName().equals(Bridge.ModuleName);
			
			 
			
				
			if(temp) {
				
				device = pairedDevices[i];
				try {
																				 
					socket = device.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"));
					receiveStream = socket.getInputStream();
					receiveReader = new BufferedReader(new InputStreamReader(receiveStream));
					//receiveReader = new BufferedReader(new Reader(receiveStream));
					
					
					sendStream = socket.getOutputStream();
					outBufferStream =  new BufferedOutputStream(sendStream);
					writer = new PrintWriter(sendStream,true);
				} 
				
				catch (IOException e) {
					Bridge.controlMessage(-1);
					
					
					
				}
				foundModule = true;
				break;
			}
			
		}
		if(foundModule == false){
			Bridge.controlMessage(-2);
			return;
			
		}
		
		new Thread() {
			@Override public void run() {
				mBluetoothAdapter.cancelDiscovery();
				try {
					socket.connect();
					
					isConnected = true;
					UnityPlayer.UnitySendMessage("BtConnector", "connection","1");
	                Bridge.controlMessage(1);
	                if(control.startListen){
	                RECEIVER = new BtReceiver();
	                RECEIVER.start();
	                }
	                //SENDER = new BtSender();
	               // SENDER.start();
					
	               
				} 
				catch (IOException e) {
					Bridge.controlMessage(-3);
					isConnected = false;
					UnityPlayer.UnitySendMessage("BtConnector", "connection","");
					
					if(receiveStream != null) {try{receiveStream.close();}  catch (Exception e0) {}}
					if(receiveReader != null) {try{receiveReader.close();}catch (Exception e1) {}}
					if(sendStream != null)  {try{sendStream.flush();sendStream.close();}catch (Exception e2) {}}
					if(writer != null) { try{writer.flush();writer.close();}catch (Exception e3) {}}
					if(outBufferStream != null) {try{outBufferStream.flush();outBufferStream.close();}catch (Exception e3) {}}
					try {
						socket.close();
					
		            
				} 
				catch (IOException e2) {
					
				}
					
		            
				
					
				}
			}
		}.start();
		
		
	}
	public boolean isConnected() { return isConnected;}
	public boolean isSending() { return control.isSending;}
	public boolean isListening(){return control.listening;}
	
	
	public void close() {
	
		
		control.startListen = false;
		
			if(receiveStream != null) {try{receiveStream.close();}  catch (Exception e) {}}
			if(receiveReader != null) {try{receiveReader.close();}catch (Exception e) {}}
			if(sendStream != null)  {try{sendStream.flush();sendStream.close();}catch (Exception e) {}}
			if(writer != null) { try{writer.flush();writer.close();}catch (Exception e) {}}
			if(outBufferStream != null) {try{outBufferStream.flush();outBufferStream.close();}catch (Exception e3) {}}
			messagesThread.outMessages.clear();
			try {
				socket.close();
			Bridge.controlMessage(2);
            
		} 
		catch (IOException e) {
			Bridge.controlMessage(-4);
		}finally{
			isConnected = false;
			UnityPlayer.UnitySendMessage("BtConnector", "connection","");}
	}
		public void defaultValues(boolean tempMode0,boolean tempMode2,boolean tempMode3,int tempLength,byte tempStopByte,boolean stop){
			control.MODE = tempMode0;
			control.MODE2 = tempMode2;
			control.MODE3 = tempMode3;
			control.stopByte = tempStopByte;
			control.startListen = stop;
			
			if(tempLength != control.length){
				tempBuffer = new byte [tempLength];
				control.length = tempLength;
			}
		
		}
		
		
		
		public  void sendString(String data) {
			char [] temp3 = data.toCharArray();
			
			char [] temp4 = Arrays.copyOf(temp3, temp3.length+1);
			temp4[temp3.length] = '\n';
			
			
			
			
			messagesThread.outMessages.add(new Object [] {(Integer)1,temp4});
			
			sendingThread();

		}
		
		private void sendingThread(){
			if(!control.isSending   ){
				control.isSending = true;
				SENDER = new BtSender(); 
				SENDER.start();
				
			} 
				
						}
		
		
		public  void sendChar(char data) {
			
			messagesThread.outMessages.add(new Object [] {(Integer)0,(int)data});
			sendingThread();
		}
		//////////////
		public  void sendBytes(byte [] data) {
			messagesThread.outMessages.add(new Object [] {(Integer)2,data});
			sendingThread();
		}
		
		public  String readLine(){
			dataAvailable = false;
			if(stringData.length() > 0){
				String tempMessage = stringData;
				stringData = "";
				lineAvailable = false;
				return tempMessage;
				
				}else  return  "";
			
			
		}
		public void doneReading(){
			dataAvailable = false;
			
			
			
			
			lineAvailable = false;
		}
		public byte [] readBuffer() { 
			dataAvailable = false;
			if (buffer == null || !bufferDataAvailable) return new byte [] {};
			if(control.MODE2) modeIndex2 = 0;
			bufferDataAvailable = false;
			
			//byte [] tempBuffer = Arrays.copyOf(buffer, buffer.length);
			//Arrays.fill(buffer, (byte)0);
			return buffer;
			
		}
		public void listen (boolean start){ // read lines
			control.startListen = start;
			control.MODE2 = false;
			control.MODE = true;
			control.MODE3 = false;
				
		if(!control.listening && start){
			
			//RECEIVER.start(); //read lines
			RECEIVER = new BtReceiver();
			RECEIVER.start();
			
				
				}
				
			

		}
		public void stopListen(){
			
			control.startListen = false;
		}
		public void stopSending(){
			
			sending = false;
		}
		
		
		
		public boolean mode(){return control.MODE;}
		
		public void listen (boolean start, int length, boolean byteLimit){// read chars
		
			
			control.startListen = start;
			control.MODE2 = false;
			control.MODE = false;
			control.MODE3 = byteLimit;
			
			
		if(start){
			if(length != control.length){
			tempBuffer = new byte [length];
			control.length = length;
			}
		if(!control.listening ){
			
			
			//RECEIVER.start();//read chars
			RECEIVER = new BtReceiver();
			RECEIVER.start();
				}
		
		}
		
		
		}
public void listen (boolean start, int length,byte stopByte){// read chars
		
			
			control.startListen = start;
			control.stopByte = stopByte;
			control.MODE2 = true;
			control.MODE = false;
			control.MODE3 = false;
		if(start){
			if(length != control.length){
			tempBuffer = new byte [length];
			control.length = length;
			}
		if(!control.listening ){
			
			
			//RECEIVER.start();//read chars
			RECEIVER = new BtReceiver();
			RECEIVER.start();
				}
		
		}
		
		
		}


		
		public boolean available(){ return dataAvailable;}
		
	//public static boolean TESTINGvariable = false;
	
	
	private class BtReceiver extends Thread {
		
		
		
		/////////////////////////////////////////String dataToSend = ""; 
		@Override public synchronized   void run() {
			
			control.listening = true;
			int firstIndex = 0;
			
		 String dataToSend;
			while(socket != null && control.startListen ) {
				control.listening = true;
				
				
				try {
					if(receiveStream.available() > 0) {
						
						
								
						
						if(control.MODE){
							if(!lineAvailable){
								
							dataToSend = receiveReader.readLine();
						
						
						
							stringData = dataToSend;
							UnityPlayer.UnitySendMessage("BtConnector", "reciever", dataToSend);
							lineAvailable = true;
							dataAvailable = true;
			                dataToSend = "";
							}
						}
						else{
						
						if(control.MODE2 || control.MODE3){if(!bufferDataAvailable) {
							int tempByte ;
							int newLength = tempBuffer.length - firstIndex  ;
							int i = firstIndex;
							boolean notFound = true;
							for(; i< newLength;i++){
								tempByte =  receiveStream.read();
								//tempByte = receiveBuffer.read();
								
								if(tempByte >=0){
									
									if((tempByte == control.stopByte) && !control.MODE3) {
										firstIndex = 0;
										buffer = java.util.Arrays.copyOf(tempBuffer,i );
										
										UnityPlayer.UnitySendMessage("BtConnector", "startReading", "");
										bufferDataAvailable = true;
										dataAvailable = true;
										notFound = false;
										
										
										  
										break;}
									tempBuffer[i] = (byte)tempByte;
								
								}
								
								else {firstIndex = i;notFound = false;break;}
								
								
							}
							if(notFound){
								firstIndex = 0;
								buffer = java.util.Arrays.copyOf(tempBuffer,tempBuffer.length);
								UnityPlayer.UnitySendMessage("BtConnector", "startReading", "");
							bufferDataAvailable = true;
							  dataAvailable = true;
							  //Arrays.fill(tempBuffer, (byte)0);
							}}
						continue;}else{	
							
							if(!bufferDataAvailable)  {

							int tempByte2 ;
							int newLength2 = tempBuffer.length - modeIndex2  ;
							//int i = modeIndex2;
							
							boolean read = false;
							int i = 0;
							for(; i< newLength2;i++){
							if(receiveStream.available() > 0) {
								//tempByte2 = receiveBuffer.read();
								tempByte2 =  receiveStream.read();
								
								if(tempByte2 >=0){
									
									tempBuffer[i] = (byte)tempByte2;
									read = true;
									//TESTINGvariable = true;
								}else {break;}
							}
								else { modeIndex2 = i;break;}
								
								
							}
							
							
							if(read){
								//modeIndex2 = 0;
								//TESTINGvariable = true;
								buffer = java.util.Arrays.copyOf(tempBuffer,i );
								UnityPlayer.UnitySendMessage("BtConnector", "startReading","");
								
								//notFound = false;
								read = false;
								bufferDataAvailable = true;
								dataAvailable = true;
							}
								
						}
							continue;}
							  
							 /* else{
								//Arrays.fill(buffer, (byte)0);
								buffer = java.util.Arrays.copyOf(tempBuffer,modeIndex2+1);
								bufferDataAvailable = true;
								dataAvailable = true;
							}*/
							 
							  
							
							 
							 
						
							 
						////////////////////}
			           
					}
				}}
				catch (IOException e) {
					control.listening = false;
					Bridge.controlMessage(-6);
				}
					
				
				
				
			} control.listening = false;
			
		}
	}
	
	private   class  BtSender extends Thread {
		public synchronized   void  run(){
			
			control.isSending = true;
			while(sending && messagesThread.outMessages.size() > 0){
				
				try{
					switch ((Integer)messagesThread.outMessages.get(0)[0]){
						case 0 : 
						outBufferStream.write((Integer)messagesThread.outMessages.get(0)[1]);
				        outBufferStream.flush();
				        break;
				        
						case 1 :writer.print((char [])messagesThread.outMessages.get(0)[1] );
								
								if(writer.checkError()) Bridge.controlMessage(-5);
						break;
						case 2 : 
						outBufferStream.write((byte [])messagesThread.outMessages.get(0)[1]);
				        outBufferStream.flush();
				        break;
				        default : break;
					}
					if(messagesThread.outMessages.size() >0)
					messagesThread.outMessages.remove(0);
					
					
				}catch (IOException e) {
					if(messagesThread.outMessages.size() >0)
						messagesThread.outMessages.remove(0);
					Bridge.controlMessage(-5);
					
				}
			}
			control.isSending =false;
			
		
		}
	}
	
	
}
